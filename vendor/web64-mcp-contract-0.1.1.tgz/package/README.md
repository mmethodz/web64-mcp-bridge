# Web64 MCP contract v0.1.1

Web64 owns this versioned contract-only package. It contains pairing bounds,
validation and WebCrypto HMAC transcript helpers, plus public knowledge envelopes,
bounded search/paging, release attestation and read-only request/reply envelopes.
It contains no project implementation, importer or build engine.
The browser imports this source; the independent bridge consumes an `npm pack`
artifact. No runtime `../react` import or toolchain installation is supported.

Wire 1 remains capability-only and backward compatible. Wire 2 explicitly binds
`project:read` to the invitation proof, browser consent and grant; it cannot
upgrade an existing wire-1 grant. M1 adds the embedded production knowledge
manifest. M2 grants bounded current-project reads, not editing or builds.
Wire 3 separately binds project editing and exposes bounded native command/reply
envelopes. M4 adds import/upload/staged-open commands within the explicit write
grant; G4 passed on 2026-09-13. It does not grant Cloud, build or
emulator authority.
Wire 4 separately binds `build` with read/build or read/write/build consent.
It adds native browser jobs and grant-private output/artifact access; existing
grants cannot acquire build authority. G5 and the G6 external-client browser
workflow passed on 2026-09-13. The
bridge remains an adapter, not a compiler or project/build authority.
Authentication uses distinct bridge
and browser transcript roles, random nonces and an explicit human consent step.
Invitations expire and are single-use; they are not HTTP client credentials.
G0 through G3 passed on 2026-09-12; G4 passed on 2026-09-13. This package is not
a hosted deployment or npm publication claim. Cloud is excluded in v1.

Wire 5 explicitly binds `runtime` alongside read and optionally write/build.
No old grant gains execution rights. Runtime start also requires build; input
and frame observation are bounded and PNG capture is emulator-only. Native
table/matrix generation uses `project:read` through the command envelope, with
browser-owned presets, validation and source formatting. The bridge contains
neither emulator nor generator implementations.
