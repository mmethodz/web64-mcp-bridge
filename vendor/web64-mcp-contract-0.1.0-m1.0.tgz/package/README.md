# Web64 MCP contract — M1 development

Web64 owns this versioned contract-only package. It contains pairing bounds,
validation and WebCrypto HMAC transcript helpers, plus public knowledge envelopes,
bounded search/paging and release attestation. It contains no project/import/build code.
The browser imports this source; the independent bridge consumes an `npm pack`
artifact. No runtime `../react` import or toolchain installation is supported.

The browser still grants only the `capabilities` method. M1 adds its embedded
production knowledge manifest to the echo. M0 remains compatible but cannot
attest a knowledge release. Authentication uses distinct bridge
and browser transcript roles, random nonces and an explicit human consent step.
Invitations expire and are single-use; they are not HTTP client credentials.
G0 browser feasibility is recorded in Web64's M0 checkpoint. G1 native-format
coverage is incomplete; this package is not a claim that the MCP campaign is complete.
