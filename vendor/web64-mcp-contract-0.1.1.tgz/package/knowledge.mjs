// Public knowledge envelopes only; no compiler, project state, or host filesystem.
export const KNOWLEDGE_VERSION = 1;
export const KNOWLEDGE_LIMITS = Object.freeze({ query: 256, results: 20, readChars: 24000,
  resources: 20000, catalogBytes: 8 * 1024 * 1024, resourceBytes: 4 * 1024 * 1024 });
const hash = /^[a-f0-9]{64}$/u;
const manifestKeys = ['schema', 'version', 'release', 'web64Version', 'sdkVersion', 'catalogSha256', 'catalogBytes', 'resourceCount'];
export function validateKnowledgeManifest(value) {
  knowledgeAssert(value && Object.keys(value).length === manifestKeys.length && manifestKeys.every(key => Object.hasOwn(value, key)));
  knowledgeAssert(value.schema === 'web64.public-knowledge-release' && value.version === KNOWLEDGE_VERSION);
  knowledgeAssert(hash.test(value.release) && hash.test(value.catalogSha256));
  knowledgeAssert([value.web64Version, value.sdkVersion].every(version => typeof version === 'string' && version.length > 0 && version.length <= 80));
  knowledgeAssert(Number.isSafeInteger(value.catalogBytes) && value.catalogBytes > 0 && value.catalogBytes <= KNOWLEDGE_LIMITS.catalogBytes);
  knowledgeAssert(Number.isSafeInteger(value.resourceCount) && value.resourceCount >= 0 && value.resourceCount <= KNOWLEDGE_LIMITS.resources);
  return value;
}
export function knowledgeAssert(condition, code = 'invalid_knowledge_request') {
  if (!condition) throw Object.assign(new Error(code), { code });
}
export function knowledgeUri(release, id) {
  knowledgeAssert(hash.test(release) && typeof id === 'string' && id.length <= 2048);
  return `web64://knowledge/${release}/${id.split('/').map(encodeURIComponent).join('/')}`;
}
export function parseKnowledgeUri(uri) {
  knowledgeAssert(typeof uri === 'string' && uri.length <= 8192);
  const match = /^web64:\/\/knowledge\/([a-f0-9]{64})\/(.+)$/u.exec(uri);
  knowledgeAssert(match && !/[?#]/u.test(uri));
  let parts;
  try { parts = match[2].split('/').map(decodeURIComponent); } catch { knowledgeAssert(false); }
  knowledgeAssert(parts.every(part => part && part !== '.' && part !== '..' && !/[\\/\u0000-\u001f\u007f]/u.test(part)));
  const result = { release: match[1], id: parts.join('/') };
  knowledgeAssert(knowledgeUri(result.release, result.id) === uri);
  return result;
}
export function validateKnowledgeCatalog(catalog) {
  knowledgeAssert(catalog?.schema === 'web64.public-knowledge' && catalog.version === KNOWLEDGE_VERSION);
  knowledgeAssert(hash.test(catalog.release) && typeof catalog.web64Version === 'string' && typeof catalog.sdkVersion === 'string');
  knowledgeAssert(Array.isArray(catalog.resources) && catalog.resources.length <= KNOWLEDGE_LIMITS.resources);
  const ids = new Set();
  for (const row of catalog.resources) {
    knowledgeAssert(row && ['sdk', 'docs', 'schemas', 'templates', 'imports'].includes(row.kind));
    knowledgeAssert(typeof row.id === 'string' && row.id.startsWith(row.kind + '/') && !ids.has(row.id));
    parseKnowledgeUri(knowledgeUri(catalog.release, row.id));
    knowledgeAssert(typeof row.title === 'string' && row.title.length <= 1024 && typeof row.summary === 'string' && row.summary.length <= 1000);
    knowledgeAssert(hash.test(row.sha256) && Number.isSafeInteger(row.bytes) && row.bytes >= 0 && row.bytes <= KNOWLEDGE_LIMITS.resourceBytes);
    knowledgeAssert(row.source && typeof row.source.authority === 'string' && row.source.authority.length <= 1024 && hash.test(row.source.contentSha256));
    knowledgeAssert(Array.isArray(row.symbols) && row.symbols.length <= 10000 && row.symbols.every(symbol => typeof symbol === 'string' && symbol.length <= 256));
    knowledgeAssert(row.searchText === undefined || (typeof row.searchText === 'string' && row.searchText.length <= KNOWLEDGE_LIMITS.resourceBytes));
    ids.add(row.id);
  }
  return catalog;
}
export function searchKnowledge(catalog, { query, kind, offset = 0, limit = 10 } = {}) {
  knowledgeAssert(typeof query === 'string' && query.trim().length > 0 && query.length <= KNOWLEDGE_LIMITS.query);
  knowledgeAssert(kind === undefined || ['sdk', 'docs', 'schemas', 'templates', 'imports'].includes(kind));
  knowledgeAssert(Number.isSafeInteger(offset) && offset >= 0 && Number.isSafeInteger(limit) && limit > 0 && limit <= KNOWLEDGE_LIMITS.results);
  const needle = query.trim().toLowerCase();
  const tokens = needle.split(/\s+/u);
  const matches = [];
  for (const row of catalog.resources) {
    if (kind && row.kind !== kind) continue;
    const terms = `${row.title}\n${row.id}\n${row.summary}\n${row.symbols.join(' ')}\n${row.searchText || ''}`.toLowerCase();
    if (!tokens.every(token => terms.includes(token))) continue;
    const score = row.symbols.some(symbol => symbol.toLowerCase() === needle) ? 100
      : row.title.toLowerCase() === needle ? 80 : row.title.toLowerCase().includes(needle) ? 50 : 10;
    matches.push({ row, score });
  }
  matches.sort((a, b) => b.score - a.score || a.row.id.localeCompare(b.row.id, 'en'));
  return { release: catalog.release, web64Version: catalog.web64Version, sdkVersion: catalog.sdkVersion,
    total: matches.length, offset, nextOffset: offset + limit < matches.length ? offset + limit : null,
    results: matches.slice(offset, offset + limit).map(({ row, score }) => {
      const text = row.searchText || row.summary;
      const start = Math.max(0, text.toLowerCase().indexOf(tokens[0]) - 120);
      return { ...row, symbols: undefined, searchText: undefined, snippet: text.slice(start, start + 500),
        uri: knowledgeUri(catalog.release, row.id), score };
    }) };
}
export function readKnowledgeText(catalog, row, content, { offset = 0, limit = KNOWLEDGE_LIMITS.readChars } = {}) {
  knowledgeAssert(Number.isSafeInteger(offset) && offset >= 0 && offset <= content.length
    && Number.isSafeInteger(limit) && limit > 0 && limit <= KNOWLEDGE_LIMITS.readChars);
  // Offsets count UTF-16 code units; never split a surrogate pair between pages.
  knowledgeAssert(!(offset > 0 && /[\uDC00-\uDFFF]/u.test(content[offset] || '') && /[\uD800-\uDBFF]/u.test(content[offset - 1])));
  let end = Math.min(content.length, offset + limit);
  if (end < content.length && /[\uD800-\uDBFF]/u.test(content[end - 1])) end--;
  knowledgeAssert(end > offset || offset === content.length);
  return { uri: knowledgeUri(catalog.release, row.id), release: catalog.release,
    web64Version: catalog.web64Version, sdkVersion: catalog.sdkVersion, source: row.source,
    sha256: row.sha256, totalChars: content.length, offsetUnit: 'UTF-16 code units', offset,
    nextOffset: end < content.length ? end : null, text: content.slice(offset, end) };
}
