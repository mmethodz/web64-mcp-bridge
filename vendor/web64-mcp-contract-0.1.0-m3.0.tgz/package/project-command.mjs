import { exactKeys, requireThat, LIMITS } from './index.mjs';
export const PROJECT_COMMAND_ACTIONS = Object.freeze(['apply', 'create', 'save', 'operation', 'artifact']);
export const PROJECT_COMMAND_ERRORS = Object.freeze(['invalid_arguments', 'scope_denied', 'grant_expired', 'grant_revoked',
  'project_unavailable', 'workspace_conflict', 'validation_failed', 'limit_exceeded', 'busy', 'operation_id_reused',
  'operation_outcome_unknown', 'artifact_expired', 'user_action_required', 'unsaved_changes', 'template_version_unavailable',
  'method_not_allowed', 'generated_file_read_only', 'generated_path_collision', 'reference_in_use']);
export function validateProjectCommandRequest(value) {
  exactKeys(value, ['action', 'input']); requireThat(PROJECT_COMMAND_ACTIONS.includes(value.action), 'method_not_allowed');
  requireThat(value.input && typeof value.input === 'object' && !Array.isArray(value.input), 'invalid_arguments');
  const fields = value.action === 'operation' ? ['operationId'] : value.action === 'artifact' ? ['artifactId', 'offset', 'limit']
    : ['operationId', 'expected', ...(value.action === 'apply' ? ['changes'] : value.action === 'create'
      ? ['templateId', 'templateVersion', 'options'] : ['mode'])];
  requireThat(Object.keys(value.input).every(key => fields.includes(key)), 'invalid_arguments');
  requireThat(new TextEncoder().encode(JSON.stringify(value)).byteLength <= LIMITS.envelope - 2048, 'limit_exceeded');
  return value;
}
export function validateProjectCommandReply(value) {
  exactKeys(value, value?.ok === true ? ['ok', 'value'] : ['ok', 'error']);
  if (value.ok === false) {
    exactKeys(value.error, ['code']); requireThat(PROJECT_COMMAND_ERRORS.includes(value.error.code), 'invalid_project_reply');
  } else requireThat(value.ok === true && value.value && typeof value.value === 'object', 'invalid_project_reply');
  requireThat(new TextEncoder().encode(JSON.stringify(value)).byteLength <= LIMITS.envelope - 512, 'invalid_project_reply');
  return value;
}
