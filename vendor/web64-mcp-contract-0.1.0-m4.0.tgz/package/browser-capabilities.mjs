import { CAPABILITIES, exactKeys, requireThat } from './index.mjs';
import { validateKnowledgeManifest } from './knowledge.mjs';

// M1 extends the existing read-only capability echo, not the set of browser RPCs.
// A deployed M0 browser remains pairable but cannot attest a knowledge release.
export function browserCapabilities(knowledge = null, projectRead = false, projectWrite = false, imports = projectWrite) {
  if (!knowledge && !projectRead) return CAPABILITIES;
  return Object.freeze({ ...CAPABILITIES, stage: projectWrite ? imports ? 'M4' : 'M3' : projectRead ? 'M2' : 'M1',
    ...(projectRead ? { contractVersion: 2, projectAccess: 'read', methods: ['capabilities', 'project.read'] } : {}),
    ...(projectWrite ? { contractVersion: 3, projectAccess: 'write', methods: ['capabilities', 'project.read', 'project.command'] } : {}),
    imports: Boolean(projectWrite && imports),
    ...(knowledge ? { knowledge: Object.freeze({ ...validateKnowledgeManifest(knowledge) }) } : {}) });
}
export function validateBrowserCapabilities(value) {
  exactKeys(value, [...Object.keys(CAPABILITIES), ...(value?.stage === 'M1' || Object.hasOwn(value || {}, 'knowledge') ? ['knowledge'] : [])]);
  const expected = browserCapabilities(value.knowledge || null, ['M2', 'M3', 'M4'].includes(value.stage), ['M3', 'M4'].includes(value.stage), value.stage === 'M4');
  for (const key of Object.keys(CAPABILITIES)) {
    if (key === 'stage') continue;
    requireThat(JSON.stringify(value[key]) === JSON.stringify(expected[key]), 'invalid_capability_echo');
  }
  requireThat(['M0', 'M1', 'M2', 'M3', 'M4'].includes(value.stage), 'invalid_capability_echo');
  if (value.knowledge) validateKnowledgeManifest(value.knowledge);
  return value;
}
