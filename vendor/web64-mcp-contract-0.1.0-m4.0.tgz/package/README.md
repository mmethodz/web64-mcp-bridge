# Web64 MCP contract — M4 development

Web64 owns this versioned contract-only package. It contains pairing bounds,
validation and WebCrypto HMAC transcript helpers, plus public knowledge envelopes,
bounded search/paging, release attestation and read-only request/reply envelopes.
It contains no project implementation, importer or build engine.
The browser imports this source; the independent bridge consumes an `npm pack`
artifact. No runtime `../react` import or toolchain installation is supported.

Wire 1 remains capability-only and backward compatible. Wire 2 explicitly binds
`project:read` to the invitation proof, browser consent and grant; it cannot
upgrade an existing wire-1 grant. M1 adds the embedded production knowledge
manifest. M2 grants bounded current-project reads, not editing or builds.
Wire 3 separately binds project editing and exposes bounded native command/reply
envelopes. M4 adds import/upload/staged-open commands within the explicit write
grant; G4 passed on 2026-09-13. It does not grant Cloud, build or
emulator authority.
Authentication uses distinct bridge
and browser transcript roles, random nonces and an explicit human consent step.
Invitations expire and are single-use; they are not HTTP client credentials.
G0 through G3 passed on 2026-09-12; G4 passed on 2026-09-13. This package is not
a claim that the MCP campaign is complete. Cloud is excluded in v1.
