import { CAPABILITIES, exactKeys, requireThat } from './index.mjs';
import { validateKnowledgeManifest } from './knowledge.mjs';

// M1 extends the existing read-only capability echo, not the set of browser RPCs.
// A deployed M0 browser remains pairable but cannot attest a knowledge release.
export function browserCapabilities(knowledge = null) {
  if (!knowledge) return CAPABILITIES;
  return Object.freeze({ ...CAPABILITIES, stage: 'M1', knowledge: Object.freeze({ ...validateKnowledgeManifest(knowledge) }) });
}
export function validateBrowserCapabilities(value) {
  exactKeys(value, [...Object.keys(CAPABILITIES), ...(value?.stage === 'M1' ? ['knowledge'] : [])]);
  for (const key of Object.keys(CAPABILITIES)) {
    if (key === 'stage') continue;
    requireThat(JSON.stringify(value[key]) === JSON.stringify(CAPABILITIES[key]), 'invalid_capability_echo');
  }
  requireThat(value.stage === 'M0' || value.stage === 'M1', 'invalid_capability_echo');
  if (value.stage === 'M1') validateKnowledgeManifest(value.knowledge);
  return value;
}
