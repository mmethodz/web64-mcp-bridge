import { exactKeys, requireThat } from './index.mjs';

export const PROJECT_READ_ACTIONS = Object.freeze(['manifest', 'file', 'configuration', 'search']);
export const PROJECT_READ_ERRORS = Object.freeze(['invalid_arguments', 'scope_denied', 'grant_expired', 'grant_revoked',
  'project_unavailable', 'stale_workspace', 'snapshot_unavailable', 'snapshot_too_large', 'duplicate_project_path',
  'page_limit_too_small', 'file_not_found', 'not_text', 'method_not_allowed', 'rate_limited', 'response_too_large']);
export function validateProjectReadRequest(value) {
  exactKeys(value, ['action', 'input']);
  requireThat(PROJECT_READ_ACTIONS.includes(value.action), 'method_not_allowed');
  const allowed = ['snapshotId', 'expected', 'offset', 'limit', 'sessionId', 'projectId',
    ...(value.action === 'file' ? ['path', 'view', 'representation'] : value.action === 'search' ? ['query'] : [])];
  requireThat(value.input && typeof value.input === 'object' && !Array.isArray(value.input), 'invalid_arguments');
  requireThat(Object.keys(value.input).every(key => allowed.includes(key)), 'invalid_arguments');
  return value;
}
// Browser errors are codes, never exception text, stack traces or source dumps.
export function validateProjectReadReply(value) {
  exactKeys(value, value?.ok === true ? ['ok', 'value'] : ['ok', 'error']);
  if (value.ok === false) {
    exactKeys(value.error, ['code']);
    requireThat(PROJECT_READ_ERRORS.includes(value.error.code), 'invalid_project_reply');
  } else {
    requireThat(value.ok === true && value.value && typeof value.value === 'object', 'invalid_project_reply');
    requireThat(typeof value.value.projectId === 'string' && typeof value.value.snapshotId === 'string'
      && typeof value.value.current === 'boolean', 'invalid_project_reply');
    exactKeys(value.value.workspaceToken, ['sessionId', 'epoch', 'generation']);
    requireThat(typeof value.value.workspaceToken.sessionId === 'string' && typeof value.value.workspaceToken.epoch === 'string'
      && Number.isSafeInteger(value.value.workspaceToken.generation) && value.value.workspaceToken.generation >= 0, 'invalid_project_reply');
  }
  return value;
}
