# Web64 MCP contract — M0

Web64 owns this versioned contract-only package. It contains pairing bounds,
validation and WebCrypto HMAC transcript helpers, not project/import/build code.
The browser imports this source; the independent bridge consumes an `npm pack`
artifact. No runtime `../react` import or toolchain installation is supported.

M0 grants only the `capabilities` method. Authentication uses distinct bridge
and browser transcript roles, random nonces and an explicit human consent step.
Invitations expire and are single-use; they are not HTTP client credentials.
Production HTTPS/browser feasibility remains a release gate, not a claim of this package.
