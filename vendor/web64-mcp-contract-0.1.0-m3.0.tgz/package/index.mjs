// M0 is deliberately connection-only. Adding project commands requires later gates.
export const WIRE_VERSION = 1;
// Wire 1 remains capability-only for existing installations. Wire 2 binds an
// explicit read scope into the invitation proof and browser consent exchange.
export const PROJECT_WIRE_VERSION = 2;
export const AUTHORING_WIRE_VERSION = 3;
export const projectReadRequested = invitation => [PROJECT_WIRE_VERSION, AUTHORING_WIRE_VERSION].includes(invitation.wire);
export const projectWriteRequested = invitation => invitation.wire === AUTHORING_WIRE_VERSION;
export const MCP_VERSIONS = Object.freeze(['2026-07-28', '2025-11-25']);
export const INVITATION_PREFIX = '#web64-mcp=';
export const LIMITS = Object.freeze({
  envelope: 256 * 1024, invitationMs: 5 * 60_000, handshakeMs: 15_000,
  grantMs: 8 * 60 * 60_000, requestMs: 10_000, clients: 8, sockets: 16,
  requests: 4, burst: 20, rate: 10
});
export const CAPABILITIES = Object.freeze({
  contractVersion: WIRE_VERSION, stage: 'M0', projectAccess: false,
  imports: false, builds: false, cloudAccess: false, emulatorControl: false,
  methods: Object.freeze(['capabilities'])
});

export function requireThat(condition, code = 'invalid_request') {
  if (!condition) throw Object.assign(new Error(code), { code });
}
export function exactKeys(value, keys) {
  requireThat(value && typeof value === 'object' && !Array.isArray(value));
  requireThat(Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key)));
}
export function hexToken(bytes = 32) {
  return Array.from(crypto.getRandomValues(new Uint8Array(bytes)), b => b.toString(16).padStart(2, '0')).join('');
}
export const isToken = value => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value);

export function validateInvitation(invitation, origin, now = Date.now()) {
  exactKeys(invitation, ['wire', 'id', 'instance', 'secret', 'port', 'expiresAt', 'origin', 'clientLabel',
    ...(projectReadRequested(invitation) ? ['scopes'] : [])]);
  requireThat([WIRE_VERSION, PROJECT_WIRE_VERSION, AUTHORING_WIRE_VERSION].includes(invitation.wire), 'contract_incompatible');
  if (projectReadRequested(invitation)) requireThat(JSON.stringify(invitation.scopes) ===
    (projectWriteRequested(invitation) ? '["project:read","project:write"]' : '["project:read"]'), 'scope_denied');
  requireThat(isToken(invitation.id) && isToken(invitation.instance) && isToken(invitation.secret));
  requireThat(Number.isInteger(invitation.port) && invitation.port > 0 && invitation.port < 65536);
  requireThat(Number.isSafeInteger(invitation.expiresAt) && invitation.expiresAt > now
    && invitation.expiresAt <= now + LIMITS.invitationMs, 'invitation_expired');
  requireThat(invitation.origin === origin && new URL(origin).origin === origin, 'origin_mismatch');
  requireThat(typeof invitation.clientLabel === 'string' && invitation.clientLabel.length > 0
    && invitation.clientLabel.length <= 80 && !/[\u0000-\u001f\u007f]/u.test(invitation.clientLabel));
  return Object.freeze({ ...invitation });
}
export function invitationFragment(invitation) {
  return INVITATION_PREFIX + encodeURIComponent(JSON.stringify(invitation));
}
export function parseInvitation(fragment, origin, now = Date.now()) {
  requireThat(typeof fragment === 'string' && fragment.length <= 2048 && fragment.startsWith(INVITATION_PREFIX));
  return validateInvitation(JSON.parse(decodeURIComponent(fragment.slice(INVITATION_PREFIX.length))), origin, now);
}
export function transcript(invitation, hello, challenge, role) {
  return JSON.stringify([invitation.wire, invitation.id, invitation.instance, invitation.origin,
    invitation.port, invitation.expiresAt, invitation.clientLabel,
    hello.clientNonce, hello.sessionId, challenge.serverNonce, role,
    ...(projectReadRequested(invitation) ? [invitation.scopes] : [])]);
}
async function key(secret) {
  requireThat(isToken(secret));
  const bytes = Uint8Array.from(secret.match(/../gu), byte => Number.parseInt(byte, 16));
  return crypto.subtle.importKey('raw', bytes, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
}
export async function proof(secret, text) {
  const bytes = new Uint8Array(await crypto.subtle.sign('HMAC', await key(secret), new TextEncoder().encode(text)));
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}
export async function verifyProof(secret, text, signature) {
  if (!isToken(signature)) return false;
  return crypto.subtle.verify('HMAC', await key(secret),
    Uint8Array.from(signature.match(/../gu), b => Number.parseInt(b, 16)), new TextEncoder().encode(text));
}
export function validateHello(message) {
  exactKeys(message, ['type', 'wire', 'id', 'instance', 'clientNonce', 'sessionId']);
  requireThat(message.type === 'hello' && [WIRE_VERSION, PROJECT_WIRE_VERSION, AUTHORING_WIRE_VERSION].includes(message.wire), 'contract_incompatible');
  requireThat(['id', 'instance', 'clientNonce', 'sessionId'].every(key => isToken(message[key])));
}
